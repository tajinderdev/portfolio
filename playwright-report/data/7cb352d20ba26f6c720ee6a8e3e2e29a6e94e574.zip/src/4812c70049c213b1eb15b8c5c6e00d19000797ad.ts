/**
 * Contact Form E2E Tests
 *
 * Tests the full browser-level contact form submission pipeline:
 * 1. Page renders the contact form
 * 2. Validation errors show for empty fields
 * 3. Successful submission works (OPTIONS preflight + POST)
 * 4. No "Unable to connect" errors appear
 */

import { test, expect, type Page } from '@playwright/test';

const BASE_URL = process.env.E2E_BASE_URL ?? 'http://localhost:3000';

async function scrollToContact(page: Page) {
  await page.evaluate(() => {
    const el = document.getElementById('contact');
    el?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });
  await page.waitForTimeout(600);
}

async function fillContactForm(
  page: Page,
  {
    name = 'Playwright Tester',
    email = 'playwright@test.com',
    subject = 'E2E Automated Test',
    message = 'This is a Playwright end-to-end test of the contact form submission pipeline.',
  } = {}
) {
  await page.fill('#contact-name', name);
  await page.fill('#contact-email', email);
  await page.fill('#contact-subject', subject);
  await page.fill('#contact-message', message);
}

test.describe('Contact Form', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto(BASE_URL);
    await page.waitForLoadState('networkidle');
    await scrollToContact(page);
  });

  test('renders the contact form with all fields', async ({ page }) => {
    await expect(page.locator('#contact-name')).toBeVisible();
    await expect(page.locator('#contact-email')).toBeVisible();
    await expect(page.locator('#contact-subject')).toBeVisible();
    await expect(page.locator('#contact-message')).toBeVisible();
    await expect(page.locator('button[type="submit"]')).toBeVisible();
  });

  test('shows validation errors when submitting empty form', async ({ page }) => {
    await page.click('button[type="submit"]');
    await expect(page.locator('#contact-name-error')).toBeVisible();
    await expect(page.locator('#contact-email-error')).toBeVisible();
    await expect(page.locator('#contact-message-error')).toBeVisible();
  });

  test('OPTIONS preflight returns 204 (not 405) — CORS fix verification', async ({ page }) => {
    const response = await page.request.fetch(`${BASE_URL}/api/contact`, {
      method: 'OPTIONS',
      headers: {
        Origin: BASE_URL,
        'Access-Control-Request-Method': 'POST',
        'Access-Control-Request-Headers': 'content-type',
      },
    });
    // Must be 204 (fixed) not 405 (old bug)
    expect(response.status()).toBe(204);
    const allowOrigin = response.headers()['access-control-allow-origin'];
    expect(allowOrigin).toBeTruthy();
  });

  test('submits successfully — no "Unable to connect" error', async ({ page }) => {
    const [apiResponse] = await Promise.all([
      page.waitForResponse(
        (resp) =>
          resp.url().includes('/api/contact') && resp.request().method() === 'POST',
        { timeout: 15000 }
      ),
      (async () => {
        await fillContactForm(page);
        // Wait 1.5s to pass the bot timing check (>1000ms interaction duration)
        await page.waitForTimeout(1500);
        await page.click('button[type="submit"]');
      })(),
    ]);

    const status = apiResponse.status();
    const body = (await apiResponse.json()) as { success: boolean; message: string };

    console.log(`/api/contact HTTP ${status}`, body);

    expect(status).toBe(200);
    expect(body.success).toBe(true);

    // UI must show success state — not "Unable to connect"
    await expect(page.locator('text=Unable to connect')).not.toBeVisible({ timeout: 5000 });
    await expect(
      page
        .locator('text=Message Sent Successfully')
        .or(page.locator('text=Thank you for reaching out'))
    ).toBeVisible({ timeout: 5000 });
  });

  test('rate limiter allows first submission', async ({ page }) => {
    const apiResponse = await page.request.post(`${BASE_URL}/api/contact`, {
      headers: { 'Content-Type': 'application/json' },
      data: {
        name: 'Rate Test',
        email: 'rate@test.com',
        subject: 'Rate Limit Check',
        message: 'Testing rate limiter does not block first submission.',
        _hp_time: 3000,
      },
    });

    // Should not be 429 for first submission
    expect(apiResponse.status()).not.toBe(429);
    expect(apiResponse.status()).toBe(200);
  });
});
